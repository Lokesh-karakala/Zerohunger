<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>GALLERY</title>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
       </head>
       <style>
       div{
        font-size:x-large;
        color: black;
         
       }
        </style>
       <body>
           
            <h1 style=" text-align: center;color: red ;">ZERO HUNGER</h1>
       <div class="container-fluid" style="background-color:white;">
       <h3 style=" text-align: center;color: red ;"></h3>
            
            <div class="col-lg-3" >
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZCw6riq-lGyDZ37duxCUgQXPE-0GTGGM24Q&usqp=CAU" class="img img-thumbnail img-respective" height="400" width="300"> 
                <h4>ZERO HUNGER</h4>
              
                </div>

                <div class="col-lg-3" >
               <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSa0HNMKwF8s3sNW_VtkjdQ47b-ATYavz1Q5Q&usqp=CAU" class="img img-thumbnail img-respective" height="300" width="350"> 
                    <h4>WE TOGETHER..FIGHT WITH FOOD CRISIS</h4>
                  
             </div>

             <div class="col-lg-3" >
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRj_5ov5OPTbW5VGYNj4xxNJ3VgOFUdmT6Jsw&usqp=CAU" class="img img-thumbnail img-respective" height="300" width="300"> 
                        <h4>SHARE AND HELP EACH OTHER</h4>
                        
             </div>

             <div class="col-lg-3" >
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQa23IGg7MFExjtLj81xIe8C_EynLGGNpRAcQ&usqp=CAU" class="img img-thumbnail img-respective" height="300" width="250"> 
                        <h4>SAY NO TO FOOD WASTAGE</h4>
              </div>
           </div>
           <br>


           <div class="container-fluid" style="background-color:white;">
            <h3 style="color:RED;"></h3>

             <div class="col-lg-3" >
                      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRlG7l48YM077XnUZaImwWXDSXysHH59aaLuQ&usqp=CAU"" class="img img-thumbnail img-respective" height="200" width="250"> 
                            <h4>ZERO HUNGER....ZERO WASTE</h4>
                        
                </div>

              <div class="col-lg-3" >
                      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2zevokrXzSvhxp0JfTxDKbYYvsEDiMCoMWg&usqp=CAU" class="img img-thumbnail img-respective" height="300" width="250"> 
                        <h4>LET'S SAVE OUR EARTH</h4>
                    
                </div>

                <div class="col-lg-3" >
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTp2wlDTPzJJPHczK3gR0i7t41mlO9Cl5suEg&usqp=CAU" class="img img-thumbnail img-respective" height="150" width="320"> 
                      <h4>PART OF SUSTANIABLE DEVELOPMENT</h4>
                </div>

                <div class="col-lg-3" >
                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAclBMVEX////ToCnQmQDSnh3TnyXQmgDlyZbRmxDRnBfSniD48OP79/DRmw7r1a727NzWqEL9+/fctGXXqknoz6Lv3b7w4MX58+jgvXrz5tDPlQDasFvlyZXjxIvp0abfunTnzJzVpTniwYTs2LXdtmvYrE/asV7L8DdXAAAJtUlEQVR4nO2dfZuqLBDGFXCForK2THs1q+//FR/erBWlbfcU4D78/jjHY3Uu74BhZmAoigKBQCAQCAQCgUAgEAgE/gbjPM9cP8P7yPYXILh8mlVmYwn7MloXt9eL1dTK0/6CPcAkFiAMPk3v2pXiSyjHI3UxjeTFrOAvnwClgBT2nvoHrEH8BbA2vG0H0hSz18cj9v40TZlCdoExQuwqOtEYU4LKkdVHf45JSyCTsOx/X1HXy08cg4wrXNZ1PWYKcV3PEFxH4zKmk+mcwIPdh3+KRiC6/W1+7ycm82gEEGo+CqJoRdGF/cFeiMZMsp2H/gl1KnQRUGGsGtFsMGJEl22FWVRwhXVKWO/OhGTfOAsjQ67sck+FQjwxvbcQCoamUPZOIGaJhbiGO9N7TxCe+hQuvFYohiGaiesdFApN1jSiMSi4wjgeTaeRGod7Pja9V0g24nonRiIx2UNmU7gV4gqTpBSfJfMNk13/FYVngo+RVEipVBhDFOOP6I8o5M+fR1LhtCjEZ9EVCcP0NxROMDOaUdvS4BqLMTwYhfCRwgVKxTzStqVJDEZ+KywpIxGN89iW5kDNKW2fZg19H4dfOYjZn895PRwxOYuLtkJpYIeisBIzPu4PoGKUrsQFszRfZ3zK3bwpmzgyPlIXtp71V+TSCaervhczHjPxsFDYUhkfCoXM0WFO0IygtEr51OgzBxjfPTidrMQCEI3kFY+Accm8tpLdi3KcEgiBj8HTnaVsQjXaOhw/JdFYXh1zdusoXjjyaXJ/OJ/8DPEbpuDb4GnYjJRAbPS7B06eom8j/EEzhiqJITzPP0jWZGmA37bi91QqXwp6p8I/wAU+TiQ+TTbys5OvmySbMQXFibkXE51BuY82oGTfxbFkf8bisi75azlfG0iYHx6VCaecRBVIEpBuHPf9upkI9w/fNkMJU7EmLISaE7rkyVPm380QD7aWlIVQY8A8NxyDowz+mfsz4bktiBEpnfb+cSPw4/H7lEKIucL0rjBOmMI0GbH4Gc2WxzROuUK4PR4/CqaQnI4z5NYhV94o7Y+Z7hgV0kIqrBDl3ZiAcdSEkkwhu5cnToMqFVDwpPxjjApZPCkUMh1jnlNlHRaIy0goLHgvcanwQ5qZ79cbjArZZ78oXJelZwplnlukCR9jUsgG4vSLwiwbR34plJ00+T6gmLGHzaID0RSSTYw/VneF6j9N8oyPRDEORwm3Rq5QlvSJ75jbFABIrCmE5zWsbgqzgpHxry0R0yezpetdjLAh5rRB/hOFOGURiK5wvkrxFiqF05JSMQ7Ze6XCGEKEFw43QfxEIT7Wyw3SFV4jgKr4phDFwpbiCV8kZgrRBRGnIedN4fhO/zsNlgZuog3z25txOL4iOVs08yGeCB/AHXnj0dwxuFhmhRN8V8he0+bDKTNRLp22XNunwL2bfj/ZrJBbqwcKP7FxNcsGv1J4bivk9oQppAaFudvp8FcKZRKYaZlKhZ+YK1wgrhtp45D9bzOUOkwU/0phAeJ0c4GIWRChcAS4Qh5WnCsibSmqqgrVUuEei40QjshlsPoVg6WpMM+kHiiPk8+AEAJ57FtRvmwVi9cQRhBseahYQohFfDjDgHltJSwNBtorTuvDKIr26zX/Aup5NTtwT2+33vJ/rg85c0lP1ewYHdjlYS1YsZf5h3byQ4FAIBAIBAKBQCAQCAQCgUAgEAgE3GFYjTDcHt6JBicAkm339gcFfSXvNQFgPoQFmjsbXiOddLbDnfh6Hb7otycAxTEkdh7tNdSJWG0stduqqEGvaVD7dui/7tG1iaxy7yicoV6FsmhsUArVjj+9lG8pW5ZovVS1LBpSL1Wr4/pWmUo1obbfW1b9D2qn/F42YaptDV/JJtRLGJtNrB374zGyQKPT666qrbRZQRYYD6qao5CNgrXN78pidupspUDPyy/bnPpLFSe415AW8sCNdECGNJJlUp1SxY3opKjSbu/U92Hp4V6BKuXrNIrqu/qWamlgne5u+ynqUBu9k6reqG+pztT34XeNcBvZ7Tq9sRmG2m0lHPh4hpQJOSl0TKYSPtNuT9LBDcOmcF8fb+q8In28SQev0+Jeo6pQ9Fq3Tf+ZDOq4jY2tp3sFSb/puMhTmPSoWE6e39cd+QTsb8ProzZEg2pDGQRivZ5PBoEdP+Aox+GgqsTn/VK2/VLqAdrSLe4NDhspWmQxlcPWsLvaT1bKedGeWYWBetConDnzOXA+op5Zn/lU1KhP+bJTuy2d+SlNVkJLVqjkjZ6sWKrjCh+XUvuFioD1WVxFwB1bo/JyyZCy3ippSLVmUUlD/YCUT9m2g8rTFE1FWNvY3ErfNeXqYJF0SEfDHJqTJtox0ZHGfUNx1Sg3HlPsIUgdaKOl2y7NISJtI3Q7mWJAk2JzKBFse9SZ6pB6sDRTytMBWZtbz2tna5pasbTttTZH4ECHRc8/Zi+9MQTbt29GqO285f22yW/UvJ9qhnMrp7/Ooo2aLIeUF85or7G5Lc9oHrhy3gZ1XJpan9ErmVf9Of/ckPP3GtmInYJ76fF0+mOzTGrr6V6BWr/QbM0tcfpcxthrVKCoj7jmFE3dbBriR58ZG6RIa2pIxuEBhsKdQxMW/We9rmHvsPUa2VidLRab/qS4HLZe/kSEEUMbqnSjHtQ/PKjYT3LDEUWG9cVFf57VZ5b9C4kqf/iscJ+5An4KA9DzMjt1rKB2u1a3/TxcsZ+pRH9kdVtvwlH/7UAg8P/liqF9DGf6v4Um22IXpE8wb2TkRmFlT2HkRKHVsGNDHCg0/17YG1BrgXaxmodTSRW72E1SORiIljdozu0PRMsbNNXeEZv0/wDM28isd1PrW9/Otrup9ZqhIrGt0LLAZgOQNRxkiid2bY2+NmADq5O+k0Tx0abn5mYvv8Vu6qjgZGKvn7oYhZzKljnFPVXhVrCVzHBYP9vsX3szLutnsY1+6nRJcWWhnzqu8T69f8pwvRNs8e4Yg37/KzfvJXvzUHT5Gy2K6VuHItGLF1zwTmuDkBd7auu3SUSpJ2fW7N8kEVFvFvUnb5GIUm8EvqejEuRJF5UU4NWTBp55YWTujMhrp37qX2VwdnlhQIyAa0+ml+3LeirBnlYlFOg1ySkw92wIfmH9gmaE1OtTQKbVP45GBA7+NqBkQv+hq6JkMYSte1vwS42IVgPZXZp9gPTn45GAoegTTGLwozwcwuDq6QxhpDiA9Fk3BwH04ZGX/TzLJxeK0WYI5qWf5/L+wzoyok1QOHyFC4qfALhaWnoB+Xb78S1bLyOlQCAQCAQCgUAgEAgEAoFAIBAIBAKBQKCP/wDaZpCDCacEmQAAAABJRU5ErkJggg==" class="img img-thumbnail img-respective" height="300" width="250"> 
                      <h4>NO TO FOOD WASTE</h4>
                </div></div><br>

<div class="container-fluid" style="background-color:white;">
            <h3 style="color: RED;"></h3>
              <div class="col-lg-3" >
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTabqPdIZ81MB1H9SphAcdRZ__wiWwCK_t8jw&usqp=CAU" class="img img-thumbnail img-respective" height="300" width="300"> 
                  <h4>PROPER USAGE OF FOOD SOURCE</h4>
                  
          </div>

          <div class="col-lg-3" >
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRow-fmjd9aDAnBu7AZ-4kA7NrsrP0gPVLliQ&usqp=CAU" class="img img-thumbnail img-respective" height="200" width="250"> 
              <h4>SAVE FOOD.. SAVE CHILD</h4>
            
      </div>

      <div class="col-lg-3" >
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSuqDuJWXITZgHJts_hQWVIJAQJ5Ihoj-peg&usqp=CAU" class="img img-thumbnail img-respective" height="300" width="300"> 
          <h4>SHARE FOOD......SHARE HAPINESS</h4>
          
  </div>

  <div class="col-lg-3" >
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeudgdBKb95EB6QdbYJOhL7DbAazT47A-WZg&usqp=CAU" class="img img-thumbnail img-respective" height="250" width="250"> 
                      <h4>BE PART OF HAPPY WORLD</h4>
                </div>

   </div>
   </body>
</html>